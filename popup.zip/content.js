body {
    font-family: Arial, sans-serif;
    padding: 10px;
    width: 200px;
}

button {
    display: block;
    margin: 10px 0;
    padding: 10px;
    width: 100%;
    font-size: 16px;
    cursor: pointer;
}
